package com.samsung.android.simplehealth;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class GlucoseDetails extends AppCompatActivity {
    private TextView type, endTime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_glucose_details);

        Intent intent = getIntent();
        String _type = intent.getStringExtra("type");

        String end_time = intent.getStringExtra("end_time");
        if (_type.equals("80002")) {
            type = (TextView) findViewById(R.id.type);
            type.setText("After Meal");
        }else if(_type.equals("80011")){
            type = (TextView) findViewById(R.id.type);
            type.setText("Before Meal");
        }else{
            type = (TextView) findViewById(R.id.type);
            type.setText("N/A");
        }
        endTime = (TextView) findViewById(R.id.endTime);
        endTime.setText(end_time);
    }
}
