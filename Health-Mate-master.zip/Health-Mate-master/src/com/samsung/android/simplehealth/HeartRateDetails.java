package com.samsung.android.simplehealth;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class HeartRateDetails extends AppCompatActivity {

    private TextView heart_beat, max, min, endTime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_heart_rate_details);

        Intent intent = getIntent();
        String heartBeat = intent.getStringExtra("heart_beat");
        String _max = intent.getStringExtra("max");
        String _min = intent.getStringExtra("min");
        String end_time = intent.getStringExtra("end_time");

        heart_beat = (TextView) findViewById(R.id.heart_beat_count);
        heart_beat.setText(heartBeat);

        max = (TextView) findViewById(R.id.max);
        max.setText(_max);

        min = (TextView) findViewById(R.id.min);
        min.setText(_min);

        endTime = (TextView) findViewById(R.id.endTime);
        endTime.setText(end_time);
    }
}
