package com.samsung.android.simplehealth;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class StepDetails extends AppCompatActivity {

    private TextView calorie, speed, distance, endTime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_step_details);
        Intent intent = getIntent();
        String calorie_count = intent.getStringExtra("calorie");
        String speed_count = intent.getStringExtra("speed");
        String distance_count = intent.getStringExtra("distance");
        String end_time = intent.getStringExtra("end_time");

        calorie = (TextView) findViewById(R.id.calorieToday);
        calorie.setText(calorie_count);

        speed = (TextView) findViewById(R.id.lastSpeed);
        speed.setText(speed_count);

        distance = (TextView) findViewById(R.id.totalDistance);
        distance.setText(distance_count);

        endTime = (TextView) findViewById(R.id.endTime);
        endTime.setText(end_time);
    }
}
