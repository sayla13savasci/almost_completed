package com.samsung.android.simplehealth;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class WaterIntakeDetails extends AppCompatActivity {
    private TextView glass_of_water, endTime, remaining, remainingRight, remainingLeft;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_water_intake_details);

        Intent intent = getIntent();
        String glasses = intent.getStringExtra("glass_of_water");

        String end_time = intent.getStringExtra("end_time");

        glass_of_water = (TextView) findViewById(R.id.glass_of_water);
        glass_of_water.setText(glasses);

        if ((8 - Integer.parseInt(glasses)) > 0) {
            remaining = (TextView) findViewById(R.id.remaining_glass);
            remaining.setText(String.valueOf(8 - Integer.parseInt(glasses)));
        } else {
            remainingRight = (TextView) findViewById(R.id.remaining_glass_right);
            remainingRight.setText("You have completed your daily recommended water intake.");
            remainingLeft = (TextView) findViewById(R.id.remaining_glass_left);
            remainingLeft.setText("");
            remaining = (TextView) findViewById(R.id.remaining_glass);
            remaining.setText("");
        }

        endTime = (TextView) findViewById(R.id.endTime);
        endTime.setText(end_time);
    }
}
