package com.samsung.android.simplehealth;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class WeightDetails extends AppCompatActivity {
    private TextView endTime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight_details);

        Intent intent = getIntent();

        String end_time = intent.getStringExtra("end_time");
        endTime = (TextView) findViewById(R.id.endTime);
        endTime.setText(end_time);
    }
}
